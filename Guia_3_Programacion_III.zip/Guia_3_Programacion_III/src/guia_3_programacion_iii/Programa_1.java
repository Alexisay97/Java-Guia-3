/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guia_3_programacion_iii;

import javax.swing.JOptionPane;

/**
 *
 * @author Alex
 */
public class Programa_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int a,b,c;
        int num1, num2, num3;
        
        
        num1 = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese un numero: ", "BIENVENIDO/A",JOptionPane.INFORMATION_MESSAGE));
        num2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese un numero: ", "NUMERO 2",JOptionPane.INFORMATION_MESSAGE));
        num3 = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese un numero: ", "NUMERO 3",JOptionPane.INFORMATION_MESSAGE));
        
        if(num1<num2){
            if(num1<num3){
                if(num2<num3){
                    JOptionPane.showMessageDialog(null,"El orden desendente de: \n" + num1 +","+num2+","+num3+" es: \n" + "** "+ num3 +" , "+ num2 +" , "+ num1+ " **");
                }else{
                    JOptionPane.showMessageDialog(null,"El orden desendente de: \n" + num1 +","+num2+","+num3+" es: \n"+ "** " + num2 + " , "+ num3 +" , "+ num1+ " **");
                }
            }else{
                JOptionPane.showMessageDialog(null,"El orden desendente de: \n" + num1 +","+num2+","+num3+" es: \n" + "** "+ num2 +" , "+ num1 +" , "+ num3+ " **");
            }
        }else{
            JOptionPane.showMessageDialog(null,"El orden desendente de: \n" + num1 +","+num2+","+num3+" es: \n"+ "** " +num1 +" , "+ num3 +" , "+ num2 + " **");
        }
            
    }
    
}
