/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guia_3_programacion_iii;

import java.util.Scanner;

/**
 *
 * @author Alex
 */
public class Programa_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       /* Declaracion de variables */
       
       int km = 0;
       double monto;
       
       Scanner s = new Scanner(System.in);
       
       System.out.println("Ingrese el numero de kilometros recorridos: ");
       km = s.nextInt();
    // Determina el monto a pagar 
        if( km <= 300 )    
            monto = 30;
        else if( km <= 1000 )
            monto = 30 + 0.15*(km-300);
        else
            monto = 30 + 0.10*(km-1000);
        
        System.out.println("El monto a pagar es de: "+ monto + " por la cantidad de: "+km+" km");
    }
    
}
