/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guia_3_programacion_iii;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Alex
 */
public class Programa_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        DecimalFormat f = new DecimalFormat("#.00");
        int docenas,pExtra = 0,ncliente = 0;
        String cliente;
        double precio = 3.0;
        double total, desc15 = 0.15,desc10 = 0.10, tDesc = 0.0;
        
        
        
       
        System.out.println("Ingrese las docenas de producto que lleva el cliente: ");
        docenas = s.nextInt();
        total = precio * docenas;
        
        if(docenas >= 3){
        tDesc = total*desc15;
        pExtra = docenas - 3;    
        }else if(docenas < 3 && docenas>0){
        tDesc = total*desc10;  
        }
        
        System.out.println("El total de su compra es de: $ "+total);
        System.out.println("El numero de docenas es de: " + docenas);
        System.out.println("El descuento es de: $ " + f.format(tDesc));
        System.out.println("La cantidad de producto regalado es de: "+pExtra +" Unidades");
        System.out.println("Su total es de: $ "+ f.format(total - tDesc));
        
        
        
        
        
    }
    
}
