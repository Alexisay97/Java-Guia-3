/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guia_3_programacion_iii;

import javax.swing.JOptionPane;

/**
 *
 * @author Alex
 */
public class Sentencia_If {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    float a, b, c, menor;     
    String primerNumero, segundoNumero, tercerNumero;
//Leer los valores de a, b, y c
    primerNumero = JOptionPane.showInputDialog("Digite el primer número: " );
    segundoNumero = JOptionPane.showInputDialog("Digite el segundo número: " );
    tercerNumero = JOptionPane.showInputDialog("Digite el tercer número: " );
    a = Float.parseFloat(primerNumero);
    b = Float.parseFloat(segundoNumero);
    c = Float.parseFloat(tercerNumero);
        if (a < b){
            if (a < c)
                menor = a;
            else
        menor = c;
        }
    else{
        if (b > c)
            menor = b;
        else
            menor = c;
        }
        System.out.println("Menor:"+menor); 
    }
    
}
