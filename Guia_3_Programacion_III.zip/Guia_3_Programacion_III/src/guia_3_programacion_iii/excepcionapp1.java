/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guia_3_programacion_iii;

/**
 *
 * @author Alex
 */
public class excepcionapp1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       String str1="12";
       String str2="0";
       String respuesta;
       long numerador, denominador, cociente;
            try{
                numerador=Integer.parseInt(str1);
                denominador=Integer.parseInt(str2);
                cociente=numerador/denominador;
                respuesta=String.valueOf(cociente);
            }catch(NumberFormatException ex){
                respuesta="Se han introducido caracteres no numéricos";
                System.out.println(respuesta);
                return;
            }catch(ArithmeticException ex){
            //Captura de mensaje generado por Java
            respuesta=ex.getMessage();
            System.out.println(respuesta);
                return;
           }finally{
                System.out.println("Esto tambien se imprime 1");
            }// ahora vea que sucede 
        System.out.println("Esto tambien se imprime"); //Esto ya no se imprime con el return
        
    } 
}
    
