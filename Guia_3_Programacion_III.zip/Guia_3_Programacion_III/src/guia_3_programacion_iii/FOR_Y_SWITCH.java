/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guia_3_programacion_iii;

/**
 *
 * @author Alex
 */
public class FOR_Y_SWITCH {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int a=1;
        String dia;
            for(int num_dia=1; num_dia<12;num_dia++){ // error num_dia estaba sin espacio 
            switch(num_dia){
                case 1 : dia="Lunes"; break;
                case 2 : dia="Martes"; break;
                case 3 : dia="Miercoles"; break;
                case 4 : dia="Jueves"; break;
                case 5 : dia="Viernes"; break;
                case 6 : dia="Sabado"; break;
                case 7 : dia="Domingo"; break;
                default : dia="¿Que Dia es Hoy?"; break;
            }// fin del switch
            System.out.println ("Hoy es "+dia+" el dia Nº "+num_dia+" de la Semana");
        }//fin del for 
    }
    
}
