/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guia_3_programacion_iii;
import javax.swing.JOptionPane;
/**
 *
 * @author Alex
 */
public class Sentencia_While {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int alumno=1, aprobado=0;
        double nota1;
        String primerNota;
            while (alumno<=5){
        primerNota = JOptionPane.showInputDialog("Digite la nota del alumno: " );
        nota1 = Double.parseDouble(primerNota);
            if (nota1 > 5.99){
                aprobado ++;
            }//fin del if
        alumno++;
 }//fin del while
        JOptionPane.showMessageDialog(null, "El numero de aprobados es: " +
        aprobado,"Resultados del examen", JOptionPane.INFORMATION_MESSAGE );
    }
    
}
