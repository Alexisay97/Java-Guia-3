/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guia_3_programacion_iii;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Alex
 */
public class Programa_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double peso =0 , altura = 0, promedio, auxPeso = 0 , auxAlt = 0;
        int npersonas = 0;
        String Dep;
        Scanner scn = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("#.00");
        
        System.out.println("Ingrese el departamento a promediar el peso y altura de su poblacion: ");
        Dep = scn.nextLine();
        do{
            try{
            System.out.println("Ingrese el numero de personas: ");
            npersonas = scn.nextInt();
            }catch(Exception ex){
            System.out.println("Ha ingresado un valor no entero: " + ex);
            
            }
        }while(npersonas<0);
        
        for(int i = 1; i<= npersonas;i++){
        
        do{
            try{
            System.out.println("Ingrese la altura m: ");
            altura = scn.nextDouble();
            auxAlt = auxAlt + altura;
            }catch(Exception ex){
            System.out.println("Ha ingresado un valor no entero: " + ex);
            }
        }while(altura < 0);
        
        do{
            try{
            System.out.println("Ingrese el peso kg: ");
            peso = scn.nextDouble();
            auxPeso = auxPeso + peso;
            }catch(Exception ex){
            System.out.println("Ha ingresado un valor no entero: " + ex);
            
            }
        }while(peso<0);
           
            
        } 
           
           System.out.println("El promedio de altura y peso del pepartamento de: "+Dep+ " es: \n");
           promedio = auxAlt / npersonas;
           System.out.println("El promedio de altura para una poblacion de: " + npersonas + " es: \n" + df.format(promedio) +" Metros");
           promedio = auxPeso / npersonas;
           System.out.println("El promedio de Peso para una poblacion de: " + npersonas + " es: \n" + df.format(promedio) + " Kilos");
    }
    
}
