/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guia_3_programacion_iii;

/**
 *
 * @author Alex
 */
public class Programa_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /* Declaracion de Variables */
        int total = 0, num = 0, aux = 0, suma = 0;
        
        while(num <= 1798) // Ciclo while especificamos que acabara cuando num sea menor a 1798 para que llegue la serie a 1800
        {
            suma = num + 2 + aux; // suma sera igual al valor del num + 2 mas el valor del auxiliar que ira cambiando
            aux = (aux+1)%2; // Sacamos el modulo del auxiliar para saber si es par
            total += suma; // sumamos e igualamos el total a la suma
            num = suma; // num sera igual a la suma
            System.out.println("N: " + num); // imprimimos cada valor de la serie
        }
       // 648720
        System.out.println("El total es: "+ total);
        
    }
    
}
