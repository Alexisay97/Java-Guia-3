/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Elementos_Programa_6;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author Alex
 */
public class Ejercicio {
    /* Se declaran variables estaticas de tipo elemento */
    static Elemento aux;
    static Elemento aux_ant;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /* Variables */
        int n;
        
        ArrayList<Elemento> elementos = new ArrayList(); // Se crea un arreglo de tipo elemento
        
        Scanner scan = new Scanner(System.in); // Clase escaner que nos permitira leer desde consola
        Elemento e = new Elemento();// Se instancia la clase Elemento
        
        
        
        /* Mensajes */
        
        System.out.println("Instruciones Ingrese la coductividad electrica y calorica sin incluir las potencias, ingrese solo numeros");
        System.out.println("Ingrese la cantidad de elementos: ");
        n =scan.nextInt();
        
        for(int i=0;i<n;i++){ // For para pedir el numero de elementos que haya ingresado el usaurio
         
        
        System.out.println("Ingrese el nombre: ");
        e.nombre = scan.next();
        System.out.println("Ingrese la conductividad Electrica: ");
        e.cond_Electrica = scan.nextFloat();
        System.out.println("Ingrese la conductividad Termica: ");
        e.cond_calorica = scan.nextFloat();
        
        elementos.add(e);
        }
        
        aux = elementos.get(0); // Primer elemento desde donde partira el forEach
            
            /* Mejore elementos conductores */
        
            System.out.println("Los dos mejores elementos conductores son: "); // Mensaje
            
            elementos.forEach(item->{ // Inicia a recorrer todo el arreglo hasta que encuentra el valor mayor
            if(item.cond_Electrica > aux.cond_Electrica){aux_ant = aux;aux = item;}});//Guarda el valor mayor que encuentre
            System.out.println("Conductividad Electrica: " + aux.nombre +" : "+ aux.cond_Electrica); //Imprime el valor mayor
            
            elementos.forEach(item->{
            if(item.cond_calorica < aux.cond_calorica){aux_ant = aux;aux = item;}});
            System.out.println("Conductividad Termica: "+ aux.nombre +" : "+ aux.cond_calorica);
        
            /* Peores Elementos Conductores */
            
            System.out.println("Los dos peores elementos conductores son: ");
            
            elementos.forEach(item->{
            if(item.cond_Electrica < aux.cond_Electrica){aux_ant = aux;aux = item;}});
            System.out.println("Conductividad Electrica: " + aux.nombre +" : "+ aux.cond_Electrica);
            
            elementos.forEach(item->{
            if(item.cond_calorica < aux.cond_calorica){aux_ant = aux;aux = item;}});
            System.out.println("Conductividad Termica: "+ aux.nombre +" : "+ aux.cond_calorica);
            
        
        
    }
    
}
