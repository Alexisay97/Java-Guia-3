/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaz.Formularios;

import Elementos_Programa_6.*;

/**
 *
 * @author Alex
 */
public class Elemento {
    String nombre;
    float cond_Electrica;
    float cond_calorica;
}
